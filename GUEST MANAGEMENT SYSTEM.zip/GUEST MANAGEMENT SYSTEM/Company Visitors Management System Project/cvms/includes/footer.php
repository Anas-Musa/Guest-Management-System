<div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Computerized Guest Information Tracking System (CGITS) 2022. All rights reserved.</p>
                                </div>
                            </div>
                        </div>